import pygame
pygame.mixer.init()
sound = pygame.mixer.Sound('meow.mp3')
sound.play()